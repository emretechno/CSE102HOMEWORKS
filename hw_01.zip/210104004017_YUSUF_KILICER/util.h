#ifndef _UTIL_H_
#define _UTIL_H_

void add_division_line(int);/*The more our number of digit of result , the longer division line.*/

int finding_digit (int); /* Calculates the digits of number.*/

void add_space(int); /*Adds space in front of the number. */

void euclid_algorithm (int ,int );


void displaying_sum(int , int);

void displaying_multiply(int , int);


void checking_range(int);



#endif /* _UTIL_H_ */

