
#include <stdio.h>
#include "util.h"

int main(void) {
    /*I chose to do the all of the functions on util.c , not main.c .That is why look the util.c please.*/
    the_menu();
    return 0;
}
