#include <stdio.h>
#include <stdlib.h> /*malloc*/
#include <string.h> /* it was obligation for strcpy and strcmp*/
#include "util.h" /*I used this header file for the functions which I used in the main.c*/


int main(){
    /*MY MAIN IS JUST USED FOR CALLING MENU FUNCTION.*/
    menu();
    return 0;
}
